// change to javascript
$(document).ready(function(){
  $('[data-toggle="tooltip"]').tooltip();   
});

$(document).ready(function(){
  $('[data-toggle="popover"]').popover();   
});

$(document).ready(function(){
  $("#myBtn").click(function(){
    $('.toast').toast('show');
  });
});